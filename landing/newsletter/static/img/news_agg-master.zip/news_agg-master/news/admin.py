from django.contrib import admin
from .models import Feed, Article

# Register your models here.

admin.site.register(Feed)
admin.site.register(Article)